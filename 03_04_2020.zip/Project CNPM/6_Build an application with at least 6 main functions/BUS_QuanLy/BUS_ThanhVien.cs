﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using DAL_QuanLy;
using DTO_QuanLy;

namespace BUS_QuanLy
{
    public class BUS_ThanhVien
    {
        DAL_ThanhVien DAL = new DAL_ThanhVien();
        public bool WriteBillsReport(string bNum,string bMoney)
        {
            return DAL.WriteBillsReport(bNum, bMoney);
        }
        public int GetCostsRoom(string cRoom)
        {
            return DAL.GetCostsRoom(cRoom);
        }
        public DataTable LoadReport()
        {
            return DAL.LoadReport();
        }
        public bool LoginAdmin(string userName,string password)
        {
            return DAL.LoginAdmin(userName,password);
        }
        public bool UpdateCustomerRoom(string room, int rStatus)
        {
            return DAL.UpdateCustomerRoom(room, rStatus);
        }
        public bool LoginEmployee(string userName, string password)
        {
            return DAL.LoginEmployee(userName, password);
        }
        public DataTable LoadDataRoom()
        {
            return DAL.LoadDataRoom();
        }

        public DataTable LoadDataFind(string ID)
        {
            return DAL.LoadDataFind(ID);
        }

        public DataTable LoadEmployee()
        {
            return DAL.LoadEmployee();
        }

        public DataTable LoadData()
        {
            return DAL.LoadData();
        }

        public bool Add(DTO_ThanhVien tv)
        {
            return DAL.Add(tv);
        }
        public bool AddEmployee(DTO_Employee tv)
        {
            return DAL.AddEmployee(tv);
        }
        public bool Update(DTO_ThanhVien tv)
        {
            return DAL.Update(tv);
        }

        public bool Pay(String idPay)
        {
            return DAL.Pay(idPay);
        }

        public bool AddRoom(DTO_Room tv)
        {
            return DAL.AddRoom(tv);
        }

        public bool UpdateRoom(DTO_Room tv)
        {
            return DAL.UpdateRoom(tv);
        }
    }
}
