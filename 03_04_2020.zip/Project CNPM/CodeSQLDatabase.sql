create database HotelManagament
go
use HotelManagament
go

create table Employee
(
	eID nvarchar(30) primary key,
	eName nvarchar(30),
	eEmail nvarchar(25),
	EPhone nvarchar(15),
	EBirth DateTime,
	ePassword nvarchar(32),
)

create table Customer
(
	cName nvarchar(30),
	cID nvarchar(30) primary key,
	cRoom nvarchar(30),
	cOtherCosts int,
	cDayCome datetime,
)

create table RoomHotel
(
	Room nvarchar(30) primary key,
	rCosts int,
	rStatus bit,
)

create table OwnerAdmin
(
	adID nvarchar(30) primary key,
	adPassword nvarchar(30),
)
	
create table BillsReport
(
	bNum nvarchar(30) primary key,
	bMoney nvarchar(30),
)