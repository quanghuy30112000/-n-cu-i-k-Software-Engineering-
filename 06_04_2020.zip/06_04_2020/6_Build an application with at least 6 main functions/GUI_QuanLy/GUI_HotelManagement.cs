﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DTO_QuanLy;
using BUS_QuanLy;
using System.Threading;
using System.Data.SqlClient;

namespace GUI_QuanLy
{
    public partial class GUI_HotelManagement : Form
    {
        BUS_ThanhVien busTV = new BUS_ThanhVien();
        string cusFoodCosts;
        public GUI_HotelManagement()
        {
            InitializeComponent();
        }
        private void LoadMenu()
        {
            dgvTV.DataSource = busTV.LoadData();
            dgvTV2.DataSource = busTV.LoadData();
            dgvTV3.DataSource = busTV.LoadDataRoom();
            dgvTV4.DataSource = busTV.LoadDataRoom();
            dgvTV6.DataSource = busTV.LoadDataFood();
            dgvTV7.DataSource = busTV.LoadData();
            dgvTV8.DataSource = busTV.LoadDataFood();
            dgvTV9.DataSource = busTV.LoadDataFoodOrder();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            LoadMenu();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {

                String cName = txtName.Text;
                String cID = txtID.Text;
                String cRoom = txtRoom.Text;
                String cOtherCosts = txtCosts.Text;
                DateTime cDaycome = dateCome.Value;
                if (txtID.Text != "" && txtName.Text != "")
                {
                    DTO_ThanhVien tv = new DTO_ThanhVien(cName, cID, cRoom, cOtherCosts, cDaycome);
                    if (busTV.Add(tv))
                        {
                            MessageBox.Show("Add customer success!😝😝");
                            busTV.UpdateCustomerRoom(cRoom, 1);
                            LoadMenu();
                            autoSet();
                        }
                    else
                        {
                            MessageBox.Show("Add customer non success!😝😝");
                        }
                    
                }
                else
                {
                    MessageBox.Show("Please fill all information!😝😝");
                }
            }
            catch { }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            cbMenu();
        }

        private void cbMenu()
        {
            this.Close();
            Thread thr = new Thread(openFormMainMenu);
            thr.SetApartmentState(ApartmentState.STA);
            thr.Start();
        }

        private void openFormMainMenu(object obj)
        {
            Application.Run(new GUI_MainMenu());
        }

        private void btnLogOutOp_Click(object sender, EventArgs e)
        {
            cbMenu();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnEdit_Click(object sender, EventArgs e)
        {   
            try
            {
                String cName = txtName.Text;
                String cID = txtID.Text;
                String cRoom = txtRoom.Text;
                String cOtherCosts = txtCosts.Text;
                DateTime cDayCome = dateCome.Value;
                if (txtID.Text != "" && txtName.Text != "")
                {
                    DTO_ThanhVien tv = new DTO_ThanhVien(cName, cID, cRoom, cOtherCosts, cDayCome);

                    if (busTV.Update(tv))
                    {
                        MessageBox.Show("Edit success!😝😝");
                        busTV.UpdateCustomerRoom(cRoom, 1);
                        LoadMenu();
                        autoSet();
                    }
                    else
                    {
                        MessageBox.Show("Edit non success😝😝");
                    }
                }
                else
                {
                    MessageBox.Show("Please input carefully😝😝");
                }
            }
            catch { }
        }

        private void dgvTV_Click(object sender, EventArgs e)
        {
            try
            {
                DataGridViewRow row = dgvTV.SelectedRows[0];
                String cName = Convert.ToString(row.Cells[0].Value);
                String cID = Convert.ToString(row.Cells[1].Value);
                String cRoom = Convert.ToString(row.Cells[2].Value);
                String cOtherCosts = Convert.ToString(row.Cells[3].Value);
                DateTime cDayCome = Convert.ToDateTime(row.Cells[4].Value);
                // update UI
                txtName.Text = cName;
                txtID.Text = cID;
                txtRoom.Text = cRoom;
                txtCosts.Text = cOtherCosts;
                dateCome.Value = cDayCome;
            }
            catch
            { }
        }

        private void dgvTV1_Click(object sender, EventArgs e)
        {
            try
            {
                DataGridViewRow row = dgvTV2.SelectedRows[0];
                String cRoom = Convert.ToString(row.Cells[2].Value);
                String cID = Convert.ToString(row.Cells[1].Value);
                txtFind.Text = cID;
            }
            catch
            { }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            dgvTV2.DataSource = busTV.LoadData();
            txtFind.Text = "";
        }

        private void btnFind_Click(object sender, EventArgs e)
        {
            dgvTV2.DataSource = busTV.LoadDataFind(txtFind.Text);
        }

        private void txtFind_TextChanged(object sender, EventArgs e)
        {

        }

        private void dgvTV3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        public void refreshManagerRoomFood()
        {
            opRoom.Text = "";
            opCosts.Text = "";
            chkStatus.Checked = false;
            txtFoodName.Text = "";
            txtFoodCosts.Text = "";
        }
        private void btnRefreshRoom_Click(object sender, EventArgs e)
        {
            dgvTV3.DataSource = busTV.LoadDataRoom();
            dgvTV6.DataSource = busTV.LoadDataFood();
            refreshManagerRoomFood();
        }

        private void btnAddRoom_Click(object sender, EventArgs e)
        {
            try
            {
                int rStatus;
                if (chkStatus.Checked)
                {
                    rStatus = 0;
                }
                else
                {
                    rStatus = 1;
                }
                String Room = opRoom.Text;
                String rCosts = opCosts.Text;
                if (Room != "" && rCosts != "")
                {
                    DTO_Room tv = new DTO_Room(Room, rCosts, rStatus);

                    if (busTV.AddRoom(tv))
                    {
                        MessageBox.Show("Add room success!😝😝");
                        refreshManagerRoomFood();
                        LoadMenu();
                    }
                    else
                    {
                        MessageBox.Show("Add room non success!😝😝");
                    }
                }
                else
                {
                    MessageBox.Show("Please fill all information!😝😝");
                }
            }
            catch { }

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void dgvTV3_Click(object sender, EventArgs e)
        {
            try
            {

                DataGridViewRow row = dgvTV3.SelectedRows[0];
                String cRoom = Convert.ToString(row.Cells[0].Value);
                String cOtherCosts = Convert.ToString(row.Cells[1].Value);
                int rStatus = Convert.ToInt32(row.Cells[2].Value);
                // update UI
                opRoom.Text = cRoom;
                opCosts.Text = cOtherCosts;
                if (rStatus==0)
                {
                    chkStatus.Checked= true;
                }
                else
                {
                    chkStatus.Checked = false;
                }
            }
            catch { }
        }

        private void btnUpdateRoom_Click(object sender, EventArgs e)
        {
            try
            {
                int rStatus;
                if (chkStatus.Checked)
                {
                    rStatus = 0;
                }
                else
                {
                    rStatus = 1;
                }
                String Room = opRoom.Text;
                String rCosts = opCosts.Text;
                if (Room != "" && rCosts != "")
                {
                    DTO_Room tv = new DTO_Room(Room, rCosts, rStatus);

                    if (busTV.UpdateRoom(tv))
                    {
                        MessageBox.Show("Update room success!😝😝");
                        refreshManagerRoomFood();
                        LoadMenu();
                    }
                    else
                    {
                        MessageBox.Show("Update room non success!😝😝");
                    }
                }
                else
                {
                    MessageBox.Show("Please fill all information!😝😝");
                }

            }
            catch { }
        }

        private void chkStatus_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.facebook.com/NQHuyOoO.OoOTHPYen");
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.facebook.com/profile.php?id=100024755624329");
        }
        private void autoSet()
        {
            txtName.Text = "";
            txtID.Text = "";
            txtRoom.Text = "";
            txtCosts.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoadMenu();
            autoSet();
        }
        private int sumDay()
        {
            DataGridViewRow row = dgvTV2.SelectedRows[0];
            DateTime dayCome = Convert.ToDateTime(row.Cells[4].Value);
            DateTime dayGo = DateTime.Now;
            TimeSpan Time = dayGo-dayCome;
            return Time.Days;
        }
        private void btnPay_Click(object sender, EventArgs e)
        {
            try
            {
                DataGridViewRow row = dgvTV2.SelectedRows[0];
                String cRoom = Convert.ToString(row.Cells[2].Value);
                String cID = Convert.ToString(row.Cells[1].Value);
                String idPay = txtFind.Text;
                String cOtherCosts = Convert.ToString(row.Cells[3].Value);
                int costsOther = Convert.ToInt32(cOtherCosts);
                int i = sumDay()+1;
                int costs = busTV.GetCostsRoom(cRoom);
                int cFood = busTV.GetCostsFood(cID);
                int money = i * costs + costsOther;
                int total = cFood + money;
                MessageBox.Show("Room Costs is: " + Convert.ToString(money) + " USD!\nFood Costs is:  "+Convert.ToString(cFood)+" USD!\nTotal Customer Pay: "+ Convert.ToString(total)+" USD!");
                DialogResult dialogResult = MessageBox.Show("Now, Pay?", "Not Pay!", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    if (idPay != "")
                    {
                        if (busTV.Pay(idPay) && busTV.WriteBillsReport(cID, Convert.ToString(money)))
                        {
                            busTV.UpdateCustomerRoom(cRoom, 0);
                            LoadMenu();
                            autoSet();
                        }
                        else
                        {
                            MessageBox.Show("Pay not success!😝😝");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select customer for pay!😝😝");
                    }
                }
                else
                {

                }
            }
            catch { }
        }

        private void dgvTV6_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnAddFood_Click(object sender, EventArgs e)
        {
            try
            {
                String nFood = txtFoodName.Text;
                String cFood = txtFoodCosts.Text;
                if (nFood != "" && cFood != "")
                {
                    DTO_Food tv = new DTO_Food(nFood, cFood);

                    if (busTV.AddFood(tv))
                    {
                        MessageBox.Show("Add Food success!😝😝");
                        refreshManagerRoomFood();
                        LoadMenu();
                    }
                    else
                    {
                        MessageBox.Show("Add Food non success!😝😝");
                    }
                }
                else
                {
                    MessageBox.Show("Please fill all information!😝😝");
                }
            }
            catch { }
        }

        private void btnUpdateFood_Click(object sender, EventArgs e)
        {
            try
            {
                String nFood = txtFoodName.Text;
                String cFood = txtFoodCosts.Text;
                if (nFood != "" && cFood != "")
                {
                    DTO_Food tv = new DTO_Food(nFood, cFood);
                    if (busTV.UpdateFood(tv))
                    {
                        MessageBox.Show("Update Food success!😝😝");
                        refreshManagerRoomFood();
                        LoadMenu();
                    }
                    else
                    {
                        MessageBox.Show("Update Food non success!😝😝");
                    }
                }
                else
                {
                    MessageBox.Show("Please fill all information!😝😝");
                }

            }
            catch { }
        }

        private void dgvTV6_Click(object sender, EventArgs e)
        {
            try
            {

                DataGridViewRow row = dgvTV6.SelectedRows[0];
                String nFood = Convert.ToString(row.Cells[0].Value);
                String cFood = Convert.ToString(row.Cells[1].Value);
                // update UI
                txtFoodName.Text = nFood;
                txtFoodCosts.Text = cFood;
            }
            catch { }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            cbMenu();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            LoadMenu();
        }

        private void dgvTV7_Click(object sender, EventArgs e)
        {
            try
            {
                DataGridViewRow row = dgvTV7.SelectedRows[0];
                String ID = Convert.ToString(row.Cells[1].Value);
                txtIDOrder.Text = ID;
            }
            catch
            { }
        }

        private void dgvTV8_Click(object sender, EventArgs e)
        {
            try
            {
                DataGridViewRow row = dgvTV8.SelectedRows[0];
                String nFood = Convert.ToString(row.Cells[0].Value);
                cusFoodCosts = Convert.ToString(row.Cells[1].Value);
                txtFoodOrder.Text = nFood;
                
            }
            catch
            { }
        }

        private void btnAddFoodOrder_Click(object sender, EventArgs e)
        {
            try
            {
                string orderID = txtIDOrder.Text;
                string orderFood = txtFoodOrder.Text;
                if (orderID != "" && orderFood != "")
                {
                    if (busTV.FoodOrder(orderID, cusFoodCosts))
                    {
                        MessageBox.Show("Order Food success!😝😝");
                        refreshManagerRoomFood();
                        LoadMenu();
                    }

                    else if (busTV.FoodOrderUpdate(orderID, orderFood))
                    {
                        MessageBox.Show("Order ad Food success!😝😝");
                        refreshManagerRoomFood();
                        LoadMenu();
                    }
                    else
                    {
                        MessageBox.Show("Order Food non success!😝😝");
                    }
                }
                else
                {
                    MessageBox.Show("Please fill all information!😝😝");
                }
            }
            catch { }
        }

        private void dataGridView1_CellContentClick_2(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}