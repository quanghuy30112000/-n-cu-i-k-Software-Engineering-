﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DTO_QuanLy
{
    public class DTO_Food
    {
        string nFood;
        string cFood;

        public string Food
        {
            get
            {
                return nFood;
            }

            set
            {
                nFood = value;
            }
        }

        public string Costs
        {
            get
            {
                return cFood;
            }

            set
            {
                cFood = value;
            }
        }
       

        public DTO_Food()
        {

        }

        public DTO_Food(string nFood, string cFood)
        {
            this.nFood = nFood;
            this.cFood = cFood;
        }
    }
}
