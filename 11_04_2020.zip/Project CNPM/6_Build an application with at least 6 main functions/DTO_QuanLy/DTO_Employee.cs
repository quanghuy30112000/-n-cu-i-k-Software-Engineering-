﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DTO_QuanLy
{
    public class DTO_Employee
    {
        string eid;
        string ename;
        string eemail;
        string ephone;
        DateTime ebirth;
        string epassword;

        public string eID
        {
            get
            {
                return eid;
            }

            set
            {
                eid = value;
            }
        }
            
        public string eName
        {
            get
            {
                return ename;
            }

            set
            {
                ename = value;
            }
        }
        public string eEmail
        {
            get
            {
                return eemail;
            }

            set
            {
                eemail = value;
            }
        }
        public string ePhone
        {
            get
            {
                return ephone;
            }

            set
            {
                ephone = value;
            }
        }

        public DateTime eBirth
        {
            get
            {
                return ebirth;
            }
            set
            {
                ebirth = value;
            }

        }

        public string ePassword
        {
            get
            {
                return epassword;
            }

            set
            {
                epassword = value;
            }
        }

        public DTO_Employee()
        {

        }

        public DTO_Employee(string eid, string ename, string eemail, string ephone, DateTime ebirth, string epassword)
        {
            this.eid = eid;
            this.ename = ename;
            this.eemail = eemail;
            this.ephone = ephone;
            this.ebirth = ebirth;
            this.epassword = epassword;
        }
    }
}
