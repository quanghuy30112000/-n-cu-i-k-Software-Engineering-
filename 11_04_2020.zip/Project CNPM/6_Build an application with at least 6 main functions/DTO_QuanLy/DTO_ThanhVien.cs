﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DTO_QuanLy
{
    public class DTO_ThanhVien
    {
        String name;
        String id;
        String room;
        String costs;
        DateTime dtCome;

             

        public String Name
        {
            get
            {
                return name;
            }

            set
            {
                name = value;
            }
        }

        public DateTime DateCome
        {
            get
            {
                return dtCome;
            }
            set
            {
                dtCome = value;
            }

        }

        public String ID
        {
            get
            {
                return id;
            }

            set
            {
                id = value;
            }
        }

        public String Room
        {
            get
            {
                return room;
            }

            set
            {
                room = value;
            }
        }
        public String Costs
        {
            get
            {
                return costs;
            }

            set
            {
                costs = value;
            }
        }
        
        public DTO_ThanhVien()
        {

        }

        public DTO_ThanhVien(String name,String id,String room,String costs,DateTime dtCome)
        {
            this.name = name;
            this.id = id;
            this.room = room;
            this.costs = costs;
            this.dtCome = dtCome;
        }
    }
}
