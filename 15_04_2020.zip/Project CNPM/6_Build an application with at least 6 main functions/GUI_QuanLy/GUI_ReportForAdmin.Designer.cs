﻿namespace GUI_QuanLy
{
    partial class GUI_ReportForAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvTV5 = new System.Windows.Forms.DataGridView();
            this.btnLogOutAdmin = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvTV6 = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTV5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTV6)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvTV5
            // 
            this.dgvTV5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTV5.Location = new System.Drawing.Point(3, 32);
            this.dgvTV5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dgvTV5.Name = "dgvTV5";
            this.dgvTV5.RowHeadersWidth = 49;
            this.dgvTV5.RowTemplate.Height = 24;
            this.dgvTV5.Size = new System.Drawing.Size(267, 344);
            this.dgvTV5.TabIndex = 0;
            this.dgvTV5.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // btnLogOutAdmin
            // 
            this.btnLogOutAdmin.Location = new System.Drawing.Point(3, 385);
            this.btnLogOutAdmin.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLogOutAdmin.Name = "btnLogOutAdmin";
            this.btnLogOutAdmin.Size = new System.Drawing.Size(785, 28);
            this.btnLogOutAdmin.TabIndex = 1;
            this.btnLogOutAdmin.Text = "Log Out";
            this.btnLogOutAdmin.UseVisualStyleBackColor = true;
            this.btnLogOutAdmin.Click += new System.EventHandler(this.btnLogOutAdmin_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(81, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 19);
            this.label1.TabIndex = 2;
            this.label1.Text = "Bills Report";
            // 
            // dgvTV6
            // 
            this.dgvTV6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTV6.Location = new System.Drawing.Point(273, 32);
            this.dgvTV6.Name = "dgvTV6";
            this.dgvTV6.RowHeadersWidth = 49;
            this.dgvTV6.RowTemplate.Height = 24;
            this.dgvTV6.Size = new System.Drawing.Size(515, 344);
            this.dgvTV6.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(519, 9);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 19);
            this.label2.TabIndex = 4;
            this.label2.Text = "Employee";
            // 
            // GUI_ReportForAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(787, 413);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dgvTV6);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnLogOutAdmin);
            this.Controls.Add(this.dgvTV5);
            this.Font = new System.Drawing.Font("Times New Roman", 10.01739F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "GUI_ReportForAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bills Report";
            this.Load += new System.EventHandler(this.GUI_ReportForAdmin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTV5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTV6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvTV5;
        private System.Windows.Forms.Button btnLogOutAdmin;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvTV6;
        private System.Windows.Forms.Label label2;
    }
}