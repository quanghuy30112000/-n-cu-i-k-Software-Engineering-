﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using DTO_QuanLy;
using BUS_QuanLy;
using System.Data.SqlClient;

namespace GUI_QuanLy
{
    public partial class GUI_ReportForAdmin : Form
    {
        BUS_ThanhVien busTV = new BUS_ThanhVien();
        public GUI_ReportForAdmin()
        {
            InitializeComponent();
        }

        private void cbMenu()
        {
            this.Close();
            Thread thr = new Thread(openFormMainMenu);
            thr.SetApartmentState(ApartmentState.STA);
            thr.Start();
        }

        private void btnLogOutAdmin_Click(object sender, EventArgs e)
        {
            cbMenu();
        }

        private void openFormMainMenu(object obj)
        {
            Application.Run(new GUI_MainMenu());
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void GUI_ReportForAdmin_Load(object sender, EventArgs e)
        {
            dgvTV5.DataSource = busTV.LoadReport();
            dgvTV6.DataSource = busTV.LoadEmployee();
        }
    }
}
