﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using DAL_QuanLy;
using DTO_QuanLy;

namespace BUS_QuanLy
{
    public class BUS_ThanhVien
    {
        DAL_ThanhVien DAL = new DAL_ThanhVien();

        public DataTable LoadDataFind(string ID)
        {
            return DAL.LoadDataFind(ID);
        }
        public DataTable LoadData()
        {
            return DAL.LoadData();
        }

        public bool Add(DTO_ThanhVien tv)
        {
            return DAL.Add(tv);
        }

        public bool Update(DTO_ThanhVien tv)
        {
            return DAL.Update(tv);
        }

        public bool Pay(int index)
        {
            return DAL.Pay(index);
        }
        public bool Clear()
        {
            return DAL.Clear();
        }
    }
}
