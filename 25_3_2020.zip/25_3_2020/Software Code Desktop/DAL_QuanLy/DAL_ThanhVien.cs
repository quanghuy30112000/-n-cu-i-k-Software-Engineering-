﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DTO_QuanLy;
using System.Xml.Linq;
using System.ComponentModel;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Threading;
using System.Collections;

namespace DAL_QuanLy
{
    public class DAL_ThanhVien : DBConnect
    {
        private SqlDataAdapter adapter;
        private DataTable DataTable;
        private SqlCommandBuilder builder;
        
        public DataTable LoadDataFind(string ID)
        {
            SqlDataAdapter data = new SqlDataAdapter("select * from Customer where cID like '%"+ID+"%' ", _conn);
            DataTable dt_Thanhvien = new DataTable();
            data.Fill(dt_Thanhvien);
            return dt_Thanhvien;
        }
        /// LoadData
        public DataTable LoadData()
        {
            SqlDataAdapter data = new SqlDataAdapter("select * from Customer", _conn);
            DataTable dt_Thanhvien = new DataTable();
            data.Fill(dt_Thanhvien);
            return dt_Thanhvien;
        }


        /// AddData
        public bool Add(DTO_ThanhVien tv)
        {
            try
            {
                _conn.Open();
                string SQL = string.Format("INSERT INTO Customer values (@cName,@cID,@cRoom,@cOtherCosts,@cDayCome)");
                SqlCommand cmd = new SqlCommand(SQL, _conn);

                cmd.Parameters.AddWithValue("@cName", tv.Name);
                cmd.Parameters.AddWithValue("@cID", tv.ID);
                cmd.Parameters.AddWithValue("@cRoom", tv.Room);
                cmd.Parameters.AddWithValue("@cOtherCosts", tv.Costs);
                cmd.Parameters.AddWithValue("@cDayCome", tv.DateCome);

                if (cmd.ExecuteNonQuery() > 0)
                    return true;

            }
            catch (Exception e)
            {

            }
            finally
            {
                _conn.Close();
            }

            return false;
        }


        /// Update
        public bool Update(DTO_ThanhVien tv)
        {
            try
            { 
                _conn.Open();
                string SQL = string.Format("UPDATE Customer Set cName = @cName, cRoom=@cRoom, cOtherCosts=@cOtherCosts, cDayCome=@cDayCome  Where cID=@cID ");
                SqlCommand cmd = new SqlCommand(SQL, _conn);

                cmd.Parameters.AddWithValue("@cName", tv.Name);
                cmd.Parameters.AddWithValue("@cID", tv.ID);
                cmd.Parameters.AddWithValue("@cRoom", tv.Room);
                cmd.Parameters.AddWithValue("@cOtherCosts", tv.Costs);
                cmd.Parameters.AddWithValue("@cDayCome", tv.DateCome);
                if (cmd.ExecuteNonQuery() > 0)
                    return true;
            }
            catch (Exception e)
            {

            }
            finally
            {
                _conn.Close();
            }

            return false;
        }


        /// Delete
        public bool Pay(int index)
        {
            try
            { 

                _conn.Open();
                DataSet set = new DataSet();
                SqlDataAdapter adapter = new SqlDataAdapter("select * from Customer", _conn);
                adapter.Fill(set, "student");
                DataTable table = set.Tables["student"];
                DataRow row = table.Rows[index];
                row.Delete();
                SqlCommandBuilder builer = new SqlCommandBuilder(adapter);
                adapter.Update(table);
                _conn.Close();
                // Query and Check
 
                    return true;

            }
            catch (Exception e)
            {

            }
            finally
            {
                _conn.Close();
            }

            return false;
        }

        public bool Clear()
        {
            try
            {

            }
            catch (Exception e)
            {

            }
            finally
            {
                _conn.Close();
            }

            return false;
        }
    }
}
