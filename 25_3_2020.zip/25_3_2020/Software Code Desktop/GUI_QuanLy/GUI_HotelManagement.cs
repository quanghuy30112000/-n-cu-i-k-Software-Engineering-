﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DTO_QuanLy;
using BUS_QuanLy;
using System.Threading;

namespace GUI_QuanLy
{
    public partial class GUI_HotelManagement : Form
    {
        BUS_ThanhVien busTV = new BUS_ThanhVien();
        public GUI_HotelManagement()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dgvTV.DataSource = busTV.LoadData();
            dgvTV2.DataSource = busTV.LoadData();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            String name = txtName.Text;
            String id = txtID.Text;
            String room = txtRoom.Text;
            String costs = txtCosts.Text;
            DateTime dtCome = dateCome.Value;
            if (txtID.Text != "" && txtName.Text != "")
            {
                DTO_ThanhVien tv = new DTO_ThanhVien(name, id, room, costs, dtCome);

                if (busTV.Add(tv))
                {
                    MessageBox.Show("Add customer success!");
                    dgvTV.DataSource = busTV.LoadData(); // refresh datagridview
                }
                else
                {
                    MessageBox.Show("Add customer non success!");
                }
            }
            else
            {
                MessageBox.Show("Please fill all information!");
            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            cbMenu();
        }

        private void cbMenu()
        {
            this.Close();
            Thread thr = new Thread(openFormMainMenu);
            thr.SetApartmentState(ApartmentState.STA);
            thr.Start();
        }

        private void openFormMainMenu(object obj)
        {
            Application.Run(new GUI_MainMenu());
        }

        private void btnLogOutOp_Click(object sender, EventArgs e)
        {
            cbMenu();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            String name = txtName.Text;
            String id = txtID.Text;
            String room = txtRoom.Text;
            String costs = txtCosts.Text;
            DateTime dtCome = dateCome.Value;
            if (txtID.Text != "" && txtName.Text != "")
            {
                DTO_ThanhVien tv = new DTO_ThanhVien(name, id, room, costs, dtCome);

                if (busTV.Update(tv))
                {
                    MessageBox.Show("Sửa thành công");
                    dgvTV.DataSource = busTV.LoadData();
                }
                else
                {
                    MessageBox.Show("Sửa ko thành công");
                }
            }
            else
            {
                MessageBox.Show("Xin hãy nhập đầy đủ");
            }
        }

        private void dgvTV_Click(object sender, EventArgs e)
        {
            // Lấy row hiện tại
            try
            {
                DataGridViewRow row = dgvTV.SelectedRows[0];
                String cName = Convert.ToString(row.Cells[0].Value);
                String cID = Convert.ToString(row.Cells[1].Value);
                String cRoom = Convert.ToString(row.Cells[2].Value);
                String cOtherCosts = Convert.ToString(row.Cells[3].Value);
                DateTime cDayCome = Convert.ToDateTime(row.Cells[4].Value);
                // update UI
                txtName.Text = cName;
                txtID.Text = cID;
                txtRoom.Text = cRoom;
                txtCosts.Text = cOtherCosts;
                dateCome.Value = cDayCome;
            }
            catch
            { }
        }

        private void dgvTV1_Click(object sender, EventArgs e)
        {

        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            dgvTV2.DataSource = busTV.LoadData();
        }

        private void btnFind_Click(object sender, EventArgs e)
        {
            dgvTV2.DataSource = busTV.LoadDataFind(txtFind.Text);
        }

        private void txtFind_TextChanged(object sender, EventArgs e)
        {

        }
    }
}