﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace GUI_QuanLy
{
    public partial class GUI_MainMenu : Form
    {
        public GUI_MainMenu()
        {
            InitializeComponent();
        }

        private void btnSignIn_Click(object sender, EventArgs e)
        {
            this.Close();
            Thread thr= new Thread(openHotelManagement);
            thr.SetApartmentState(ApartmentState.STA);
            thr.Start();
        }

        private void openHotelManagement(object obj)
        {
            Application.Run(new GUI_HotelManagement());
        }

        private void btnLogIn_Click(object sender, EventArgs e)
        {
            this.Close();
            Thread thr = new Thread(openFormSignUp);
            thr.SetApartmentState(ApartmentState.STA);
            thr.Start();
        }

        private void openFormSignUp(object obj)
        {
            Application.Run(new GUI_SignUp());
        }

        private void GUI_MainMenu_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void ID_Click(object sender, EventArgs e)
        {

        }

        private void Password_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {

        }

        private void textBox_Click(object sender, EventArgs e)
        {

        }
    }
}
