﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
namespace GUI_QuanLy
{
    public partial class GUI_SignUp : Form
    {
        public GUI_SignUp()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void emName_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void lable1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void GUI_SignUp_Load(object sender, EventArgs e)
        {

        }

        private void emPassword2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {

            if (emPassword1.Text == emPassword2.Text && emName.Text!="" && emId.Text!="")
            {
                MessageBox.Show("Create success! \nPlease sign in. Enjoy!");
                cbMenu();
            }
            else
            {
                MessageBox.Show("Information incorrect! \nPlease try again!");
            }

            
        }
        
        private void cbMenu()
        {
            this.Close();
            Thread thr = new Thread(openFormMainMenu);
            thr.SetApartmentState(ApartmentState.STA);
            thr.Start();
        }

        private void openFormMainMenu(object obj)
        {
            Application.Run(new GUI_MainMenu());
        }

        private void btnSignIn_Click(object sender, EventArgs e)
        {
            cbMenu();
        }
    }
}

