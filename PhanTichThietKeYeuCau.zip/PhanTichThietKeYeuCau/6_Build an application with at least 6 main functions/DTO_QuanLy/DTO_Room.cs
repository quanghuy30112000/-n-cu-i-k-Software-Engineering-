﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DTO_QuanLy
{
    public class DTO_Room
    {
        String room;
        String costs;
        string rnumpeople;
        int status;

        public String Room
        {
            get
            {
                return room;
            }

            set
            {
                room = value;
            }
        }

        public String rNumPeople
        { 
            get
            {
                return rnumpeople;
            }
            set
            {
                rnumpeople = value;
            }
        }
        public String Costs
        {
            get
            {
                return costs;
            }

            set
            {
                costs = value;
            }
        }
        public int rStatus
        {
            get
            {
                return status;
            }

            set
            {
                status = value;
            }
        }

        public DTO_Room()
        {

        }

        public DTO_Room(String room, String costs, String rnumpeople,int rstatus)
        {
            this.room = room;
            this.costs = costs;
            this.rnumpeople = rnumpeople;
            this.status = rstatus;
        }
    }
}
