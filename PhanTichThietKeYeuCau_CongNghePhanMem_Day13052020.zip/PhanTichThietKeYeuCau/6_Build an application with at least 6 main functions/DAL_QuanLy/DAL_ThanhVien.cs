﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DTO_QuanLy;
using System.Xml.Linq;
using System.ComponentModel;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Threading;
using System.Collections;


namespace DAL_QuanLy
{
    public class DAL_ThanhVien : DBConnect
    {
        private SqlDataAdapter adapter;
        private DataTable DataTable;
        private SqlCommandBuilder builder;
        
        //Login with Admin
        public bool LoginAdmin(string userName, string password)
        {
            AccessData acc = new AccessData();
            SqlDataReader reader = acc.ExecuteReader("select adID, adPassword from OwnerAdmin");
            while (reader.Read())
            {
                if (reader[0].ToString() == userName && reader[1].ToString() == password)
                {
                    // reader[0] for textbox Username
                    // reader[1] for textbox Password
                    return true;
                }
            }
            return false;

        }
        //Write Bills Report for Owner
        public bool WriteBillsReport(string bNum, string bMoney)
        {
            try
            {
                _conn.Open();
                string SQL = string.Format("insert into BillsReport values (@bNum,@bMoney)");
                SqlCommand cmd = new SqlCommand(SQL, _conn);
                cmd.Parameters.AddWithValue("@bNum", bNum);
                cmd.Parameters.AddWithValue("@bMoney", bMoney);
                if (cmd.ExecuteNonQuery() > 0)
                    return true;
            }
            catch (Exception e)
            {

            }
            finally
            {
                _conn.Close();
            }
            return false;
        }

        //Get Costs of Room
        public int GetCostsRoom(string cRoom)
        {
            int i = 0;
            AccessData acc = new AccessData();
            SqlDataReader reader = acc.ExecuteReader("select Room, rCosts from RoomHotel");
            while (reader.Read())
            {
                if (reader[0].ToString() == cRoom)
                {
                    i =Convert.ToInt32(reader[1].ToString());
                    return i;
                    // reader[0] for Room
                    // reader[1] for CostsRoom
                }
            }
            return i;
        }
        public int GetCostsFood(string orderID)
        {
            int i = 0;
            AccessData acc = new AccessData();
            SqlDataReader reader = acc.ExecuteReader("select orderID, oderCostsFood from FoodOrder");
            while (reader.Read())
            {
                if (reader[0].ToString() == orderID)
                {
                    i = Convert.ToInt32(reader[1].ToString());
                    return i;
                }
            }
            return i;
        }

        //Login with Employee
        public bool LoginEmployee(string userName, string password)
        {
            AccessData acc = new AccessData();
            SqlDataReader reader = acc.ExecuteReader("select eID, ePassword from Employee");
            while (reader.Read())
            {
                if (reader[0].ToString() == userName && reader[1].ToString() == password)
                {
                    return true;
                }
            }
            return false;

        }

        public DataTable LoadDataFoodOrder()
        {
            SqlDataAdapter data = new SqlDataAdapter("select * from FoodOrder", _conn);
            DataTable dt_Thanhvien = new DataTable();
            data.Fill(dt_Thanhvien);
            return dt_Thanhvien;
        }
        //LoadData Employee
        public DataTable LoadEmployee()
        {
            SqlDataAdapter data = new SqlDataAdapter("select * from Employee", _conn);
            DataTable dt_Thanhvien = new DataTable();
            data.Fill(dt_Thanhvien);
            return dt_Thanhvien;
        }
        //LoadData when find Customer
        public DataTable LoadDataFind(string ID)
        {
            SqlDataAdapter data = new SqlDataAdapter("select * from Customer where cID like '%"+ID+"%' ", _conn);
            DataTable dt_Thanhvien = new DataTable();
            data.Fill(dt_Thanhvien);
            return dt_Thanhvien;
        }

        //LoadData when sign in with Admin
        public DataTable LoadReport()
        {
            SqlDataAdapter data = new SqlDataAdapter("select * from BillsReport", _conn);
            DataTable dt_Thanhvien = new DataTable();
            data.Fill(dt_Thanhvien);
            return dt_Thanhvien;
        }
        //LoadData Customer when Employee sign in
        public DataTable LoadData()
        {
            SqlDataAdapter data = new SqlDataAdapter("select * from Customer", _conn);
            DataTable dt_Thanhvien = new DataTable();
            data.Fill(dt_Thanhvien);
            return dt_Thanhvien;
        }

        //Loaddata Room when Employee sign in
        public DataTable LoadDataRoom()
        {
            SqlDataAdapter data = new SqlDataAdapter("select * from RoomHotel", _conn);
            DataTable dt_Thanhvien = new DataTable();
            data.Fill(dt_Thanhvien);
            return dt_Thanhvien;
        }

        /// AddData of Customer
        public bool Add(DTO_ThanhVien tv)
        {
            try
            {
                _conn.Open();
                string SQL = string.Format("insert into Customer values (@cName,@cID,@cRoom,@cOtherCosts,@cDayCome)");
                SqlCommand cmd = new SqlCommand(SQL, _conn);
                cmd.Parameters.AddWithValue("@cName", tv.Name);
                cmd.Parameters.AddWithValue("@cID", tv.ID);
                cmd.Parameters.AddWithValue("@cRoom", tv.Room);
                cmd.Parameters.AddWithValue("@cOtherCosts", tv.Costs);
                cmd.Parameters.AddWithValue("@cDayCome", tv.DateCome);

                if (cmd.ExecuteNonQuery() > 0)
                    return true;

            }
            catch (Exception e)
            {

            }
            finally
            {
                _conn.Close();
            }

            return false;
        }

        //AddData of Employee
        public bool AddEmployee(DTO_Employee tv)
        {
            try
            {
                _conn.Open();
                string SQL = string.Format("insert into Employee values (@eID,@eName,@eEmail,@ePhone,@eBirth,@ePassword)");
                SqlCommand cmd = new SqlCommand(SQL, _conn);
                cmd.Parameters.AddWithValue("@eID", tv.eID);
                cmd.Parameters.AddWithValue("@eName", tv.eName);
                cmd.Parameters.AddWithValue("@eEmail", tv.eEmail);
                cmd.Parameters.AddWithValue("@ePhone", tv.ePhone);
                cmd.Parameters.AddWithValue("@eBirth", tv.eBirth);
                cmd.Parameters.AddWithValue("@ePassword", tv.ePassword);
                if (cmd.ExecuteNonQuery() > 0)
                    return true;

            }
            catch (Exception e)
            {

            }
            finally
            {
                _conn.Close();
            }

            return false;
        }
        public bool AddFood(DTO_Food tv)
        {
            try
            {
                _conn.Open();
                string SQL = string.Format("insert into Food values (@nFood,@cFood)");
                SqlCommand cmd = new SqlCommand(SQL, _conn);
                cmd.Parameters.AddWithValue("@nFood", tv.Food);
                cmd.Parameters.AddWithValue("@cFood", tv.Costs);
                if (cmd.ExecuteNonQuery() > 0)
                    return true;

            }
            catch (Exception e)
            {

            }
            finally
            {
                _conn.Close();
            }

            return false;
        }
        public bool UpdateFood(DTO_Food tv)
        {
            try
            {
                _conn.Open();
                string SQL = string.Format("update Food set cFood=@cFood Where nFood=@nFood ");
                SqlCommand cmd = new SqlCommand(SQL, _conn);
                cmd.Parameters.AddWithValue("@nFood", tv.Food);
                cmd.Parameters.AddWithValue("@cFood", tv.Costs);
                if (cmd.ExecuteNonQuery() > 0)
                    return true;

            }
            catch (Exception e)
            {

            }
            finally
            {
                _conn.Close();
            }

            return false;
        }
        public DataTable LoadDataFood()
        {
                SqlDataAdapter data = new SqlDataAdapter("select * from Food", _conn);
                DataTable dt_Thanhvien = new DataTable();
                data.Fill(dt_Thanhvien);
                return dt_Thanhvien;

        }

        /// Update DataBase of Customer
        public bool Update(DTO_ThanhVien tv)
        {
            try
            { 
                _conn.Open();
                string SQL = string.Format("UPDATE Customer Set cName = @cName, cRoom=@cRoom, cOtherCosts=@cOtherCosts, cDayCome=@cDayCome Where cID=@cID ");
                SqlCommand cmd = new SqlCommand(SQL, _conn);
                cmd.Parameters.AddWithValue("@cName", tv.Name);
                cmd.Parameters.AddWithValue("@cID", tv.ID);
                cmd.Parameters.AddWithValue("@cRoom", tv.Room);
                cmd.Parameters.AddWithValue("@cOtherCosts", tv.Costs);
                cmd.Parameters.AddWithValue("@cDayCome", tv.DateCome);
                if (cmd.ExecuteNonQuery() > 0)
                    return true;
            }
            catch (Exception e)
            {
            }
            finally
            {
                _conn.Close();
            }

            return false;
        }


        ///Paid Customer
        public bool Pay(String idPay)
        {
            try
            {
                _conn.Open();
                string SQL = string.Format("delete from Customer where cRoom = @cRoom");
                SqlCommand cmd = new SqlCommand(SQL, _conn);
                cmd.Parameters.AddWithValue("@cRoom", idPay);
                if (cmd.ExecuteNonQuery() > 0)
                    return true;
            }
            catch (Exception e)
            {
            }
            finally
            {
                _conn.Close();
            }

            return false;
        }

        //AddRoom 
        public bool AddRoom(DTO_Room tv)
        {
            try
            {
                _conn.Open();
                string SQL = string.Format("INSERT INTO RoomHotel values (@Room,@rCosts,@rNumPeople,@rStatus)");
                SqlCommand cmd = new SqlCommand(SQL, _conn);
                cmd.Parameters.AddWithValue("@Room", tv.Room);
                int costs = Int32.Parse(tv.Costs);
                cmd.Parameters.AddWithValue("@rCosts",costs);
                cmd.Parameters.AddWithValue("@rNumPeople", tv.rNumPeople);
                cmd.Parameters.AddWithValue("@rStatus", tv.rStatus);
                if (cmd.ExecuteNonQuery() > 0)
                    return true;
            }
            catch (Exception e)
            {

            }
            finally
            {
                _conn.Close();
            }
            return false;
        }

        //Update Room
        public bool UpdateRoom(DTO_Room tv)
        {
            try
            {        
                _conn.Open();
                string SQL = string.Format("update RoomHotel set rCosts=@rCosts, rNumPeople=@rNumPeople, rStatus=@rStatus  Where Room = @Room ");
                SqlCommand cmd = new SqlCommand(SQL, _conn);
                cmd.Parameters.AddWithValue("@Room", tv.Room);
                int costs = Int32.Parse(tv.Costs);
                cmd.Parameters.AddWithValue("@rCosts", costs);
                cmd.Parameters.AddWithValue("@rNumPeople", tv.rNumPeople);
                cmd.Parameters.AddWithValue("@rStatus", tv.rStatus);
                if (cmd.ExecuteNonQuery() > 0)
                    return true;
            }
            catch (Exception e)
            {

            }
            finally
            {
                _conn.Close();
            }

            return false;
        }
        public bool UpdateCustomerRoom(string room,int rStatus)
        {
            try
            {
                _conn.Open();
                string SQL = string.Format("UPDATE RoomHotel Set rStatus=@rStatus  Where Room = @Room ");
                SqlCommand cmd = new SqlCommand(SQL, _conn);
                cmd.Parameters.AddWithValue("@Room", room);
                cmd.Parameters.AddWithValue("@rStatus", rStatus);
                if (cmd.ExecuteNonQuery() > 0)
                    return true;
            }
            catch (Exception e)
            {

            }
            finally
            {
                _conn.Close();
            }

            return false;
        }
        public bool DeleteFood(DTO_Food tv)
        {
            try
            {
                _conn.Open();
                string SQL = string.Format("delete from Food where nFood = @nFood ");
                SqlCommand cmd = new SqlCommand(SQL, _conn);
                cmd.Parameters.AddWithValue("@nFood", tv.Food);
                if (cmd.ExecuteNonQuery() > 0)
                    return true;
            }
            catch (Exception e)
            {

            }
            finally
            {
                _conn.Close();
            }

            return false;
        }
        public bool DeleteCosts(string cID)
        {
            try
            {
                _conn.Open();
                string SQL = string.Format("delete from FoodOrder where orderID =@orderID");
                SqlCommand cmd = new SqlCommand(SQL, _conn);
                cmd.Parameters.AddWithValue("@orderID", cID);
                if (cmd.ExecuteNonQuery() > 0)
                    return true;
            }
            catch (Exception e)
            {

            }
            finally
            {
                _conn.Close();
            }

            return false;
        }
        public bool DeleteRoom(DTO_Room tv)
        {
            try
            {
                _conn.Open();
                string SQL = string.Format("delete from RoomHotel where Room = @Room ");
                SqlCommand cmd = new SqlCommand(SQL, _conn);
                cmd.Parameters.AddWithValue("@Room", tv.Room);
                if (cmd.ExecuteNonQuery() > 0)
                    return true;
            }
            catch (Exception e)
            {

            }
            finally
            {
                _conn.Close();
            }

            return false;
        }

        public bool FoodOrder(string id, string costs)
        {
            try
            {
                _conn.Open();
                string SQL = string.Format("INSERT INTO FoodOrder values (@orderID,@oderCostsFood)");
                SqlCommand cmd = new SqlCommand(SQL, _conn);
                cmd.Parameters.AddWithValue("@orderID", id);
                cmd.Parameters.AddWithValue("@oderCostsFood", costs);
                if (cmd.ExecuteNonQuery() > 0)
                    return true;
            }
            catch (Exception e)
            {

            }
            finally
            {
                _conn.Close();
            }
            return false;
        }

        public bool FoodOrderUpdate(string orderID, string orderFood)
        {
            try
            {
                int i1 = 0;
                AccessData acc = new AccessData();
                SqlDataReader reader = acc.ExecuteReader("select nFood, cFood from Food ");
                while (reader.Read())
                {
                    if (reader[0].ToString() == orderFood)
                    {
                        i1 =Convert.ToInt32(reader[1].ToString());
                    }
                }

                int i2 = 0;
                acc = new AccessData();
                reader = acc.ExecuteReader("select orderID, oderCostsFood from FoodOrder ");
                while (reader.Read())
                {
                    if (reader[0].ToString() == orderID)
                    {
                        i2 = Convert.ToInt32(reader[1].ToString());
                    }
                }
                int i3 = i1 + i2;
                string ncosts = Convert.ToString(i3);
                _conn.Open();
                string SQL = string.Format("UPDATE FoodOrder Set oderCostsFood=@oderCostsFood  Where orderID = @orderID ");
                SqlCommand cmd = new SqlCommand(SQL, _conn);
                cmd.Parameters.AddWithValue("@orderID", orderID);
                cmd.Parameters.AddWithValue("@oderCostsFood", ncosts);
                if (cmd.ExecuteNonQuery() > 0)
                    return true;
            }
            catch (Exception e)
            {

            }
            finally
            {
                _conn.Close();
            }

            return false;
        }


    }
}
